import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  String linha1 = "";
  String linha2 = "";
  String linha3 = "";

  void _segundaH() {
    setState(() {
      linha1 = "13:20-15:00: História";
      linha2 = "15:00-17:00: GSW";
      linha3 = "17:00-18:40: CNW II";
    });
  }

  void _tercaH() {
    setState(() {
      linha1 = "13:20-15:00: Portugues";
      linha2 = "15:00-17:00: aula curso";
      linha3 = "17:00-18:40: Geografia";
    });
  }

  void _quartaH() {
    setState(() {
      linha1 = "13:20-15:00: Portugues";
      linha2 = "15:00-17:00: aaaa";
      linha3 = "17:00-18:40: aaaa";
    });
  }

  void _quintaH() {
    setState(() {
      linha1 = "13:20-15:00: Matematica";
      linha2 = "15:00-16:50: Filosofia";
      linha3 = "17:10-18:40: Matematica";
    });
  }

  void _sextaH() {
    setState(() {
      linha1 = "13:20-15:00: Portugues";
      linha2 = "15:00-17:00: aaaa";
      linha3 = "17:00-18:40: aaaa";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,

        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text('You have pushed the button this many times:'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: _segundaH,
                    child: const Text("seg"),
                  ),
                  ElevatedButton(onPressed: _tercaH, child: const Text("ter")),
                  ElevatedButton(
                    onPressed: _quartaH,
                    child: const Text("quar"),
                  ),
                  ElevatedButton(onPressed: _quintaH, child: const Text("qui")),
                  ElevatedButton(onPressed: _sextaH, child: const Text("sex")),
                ],
              ),
            ),
            Text('$linha1', style: Theme.of(context).textTheme.headlineMedium),
            Text('$linha2', style: Theme.of(context).textTheme.headlineMedium),
            Text('$linha3', style: Theme.of(context).textTheme.headlineMedium),
          ],
        ),
      ),
    );
  }
}
