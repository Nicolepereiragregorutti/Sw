// Função principal do carrinho
document.addEventListener("DOMContentLoaded", function () {
    const botaoCarrinho = document.getElementById("botao-carrinho");
    const carrinho = document.getElementById("carrinho");
    const itensCarrinho = document.getElementById("itens-carrinho");
    const totalCarrinho = document.getElementById("total-carrinho");
    const finalizarCompra = document.getElementById("finalizar-compra");
    const limparCarrinho = document.getElementById("limpar-carrinho");
    const botoesAdicionar = document.querySelectorAll(".adicionar");
  
    let carrinhoItens = [];
  
    // Exibe/oculta o carrinho
    botaoCarrinho.addEventListener("click", () => {
      carrinho.classList.toggle("ativo");
    });
  
    // Função auxiliar para formatar valores para moeda brasileira
    function formatarPreco(valor) {
      return valor.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL",
      });
    }
  
    // Adiciona os eventos de clique nos botões de "Adicionar ao carrinho"
    botoesAdicionar.forEach((botao) => {
      botao.addEventListener("click", function () {
        const produto = this.closest(".produto");
        const nome = produto.querySelector("h3").textContent;
        const preco = parseFloat(
          produto.querySelector("p").textContent.replace("R$", "").replace(",", ".")
        );
        const id = produto.getAttribute("data-id");
  
        const existente = carrinhoItens.find((item) => item.id === id);
  
        if (existente) {
          existente.quantidade++;
        } else {
          carrinhoItens.push({
            id,
            nome,
            preco,
            quantidade: 1,
          });
        }
  
        // Atualiza a interface do carrinho e o abre
        atualizarCarrinho();
        carrinho.classList.add("ativo");
      });
    });
  
    // Atualiza a interface do carrinho lateral
    function atualizarCarrinho() {
      itensCarrinho.innerHTML = "";
      let total = 0;
  
      carrinhoItens.forEach((item) => {
        const subtotal = item.preco * item.quantidade;
        total += subtotal;
  
        const div = document.createElement("div");
        div.classList.add("item-carrinho");
        div.innerHTML = `
          <strong>${item.nome}</strong> 
          <p>Preço: ${formatarPreco(item.preco)} x 
          <input class="quantidade" data-id="${item.id}" type="number" value="${item.quantidade}" min="1"></p>
          <p>Subtotal: ${formatarPreco(subtotal)}</p>
          <button class="remover" data-id="${item.id}" data-acao="remover">Remover</button>
        `;
        itensCarrinho.appendChild(div);
      });
  
      totalCarrinho.textContent = `Total: ${formatarPreco(total)}`;
    }
  
    // Configura os eventos de alteração de quantidade dos produtos no carrinho
    itensCarrinho.addEventListener("input", function (e) {
      if (e.target.classList.contains("quantidade")) {
        const id = e.target.getAttribute("data-id");
        const novaQuantidade = parseInt(e.target.value);
  
        const item = carrinhoItens.find((produto) => produto.id === id);
        if (item && novaQuantidade > 0) {
          item.quantidade = novaQuantidade;
          atualizarCarrinho();
        }
      }
    });
  
    // Remove item do carrinho
    itensCarrinho.addEventListener("click", function (e) {
      if (e.target.classList.contains("remover")) {
        const id = e.target.getAttribute("data-id");
        carrinhoItens = carrinhoItens.filter((item) => item.id !== id);
        atualizarCarrinho();
      }
    });
  
    // Limpa o carrinho
    limparCarrinho.addEventListener("click", function () {
      carrinhoItens = [];
      atualizarCarrinho();
    });
  
    // Redireciona para a página de finalização da compra
    finalizarCompra.addEventListener("click", function () {
      window.location.href = "finalizar.html";
    });
  
    // Função auxiliar para fechar o carrinho
    function fecharCarrinho() {
      carrinho.classList.remove("ativo");
    }
  
    // Fecha o carrinho clicando fora dele
    document.addEventListener("click", function (e) {
      if (!carrinho.contains(e.target) && !botaoCarrinho.contains(e.target)) {
        fecharCarrinho();
      }
    });
  });
  